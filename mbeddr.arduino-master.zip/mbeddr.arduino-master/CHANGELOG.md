## Changelog

### 0.1.7 (Saker)
- bug fixes
- adapted support library to new AVR SDK

### 0.1.6 (Hobby)
- bug fix release for 0.1.5

### 0.1.5 (Kestrel)
- basic migration to MPS 3.4

### 0.1.0 (Merlin)
- initial release

